package com.example.konversisuhu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MassaActivity extends AppCompatActivity {

    EditText inputMassa;
    Spinner spinnerDari, spinnerKe;
    Button btnKonversi;
    TextView tvHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_massa);

        inputMassa = findViewById(R.id.inputMassa);
        spinnerDari = findViewById(R.id.spinnerMassaDari);
        spinnerKe = findViewById(R.id.spinnerMassaKe);
        btnKonversi = findViewById(R.id.btnKonversiMassa);
        tvHasil = findViewById(R.id.tvHasilMassa);

        final String[] satuan = {"Gram", "Kilogram", "Ons"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, satuan);
        spinnerDari.setAdapter(adapter);
        spinnerKe.setAdapter(adapter);

        btnKonversi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double nilai = Double.parseDouble(inputMassa.getText().toString());
                String dari = spinnerDari.getSelectedItem().toString();
                String ke = spinnerKe.getSelectedItem().toString();
                double gram = 0;

                // ubah dulu ke gram
                if (dari.equals("Kilogram")) gram = nilai * 1000;
                else if (dari.equals("Ons")) gram = nilai * 100;
                else gram = nilai;

                // ubah ke satuan target
                double hasil = 0;
                if (ke.equals("Kilogram")) hasil = gram / 1000;
                else if (ke.equals("Ons")) hasil = gram / 100;
                else hasil = gram;

                tvHasil.setText("Hasil: " + hasil + " " + ke);
            }
        });
    }
}

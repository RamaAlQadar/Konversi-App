package com.example.konversisuhu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class SuhuActivity extends AppCompatActivity {

    EditText inputNilai;
    Spinner spinnerDari, spinnerKe;
    Button btnKonversi;
    TextView tvHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suhu);

        inputNilai = findViewById(R.id.inputNilai);
        spinnerDari = findViewById(R.id.spinnerDari);
        spinnerKe = findViewById(R.id.spinnerKe);
        btnKonversi = findViewById(R.id.btnKonversi);
        tvHasil = findViewById(R.id.tvHasil);

        final String[] satuan = {"Celsius", "Fahrenheit", "Kelvin"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, satuan);
        spinnerDari.setAdapter(adapter);
        spinnerKe.setAdapter(adapter);

        btnKonversi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dari = spinnerDari.getSelectedItem().toString();
                String ke = spinnerKe.getSelectedItem().toString();
                double nilai = Double.parseDouble(inputNilai.getText().toString());
                double hasil = 0;

                // ubah dulu ke Celsius
                if (dari.equals("Fahrenheit")) {
                    nilai = (nilai - 32) * 5 / 9;
                } else if (dari.equals("Kelvin")) {
                    nilai = nilai - 273.15;
                }

                // konversi dari Celsius ke target
                if (ke.equals("Celsius")) {
                    hasil = nilai;
                } else if (ke.equals("Fahrenheit")) {
                    hasil = (nilai * 9 / 5) + 32;
                } else if (ke.equals("Kelvin")) {
                    hasil = nilai + 273.15;
                }

                tvHasil.setText("Hasil: " + hasil + " " + ke);
            }
        });
    }
}


package com.example.konversisuhu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class JarakActivity extends AppCompatActivity {

    private EditText inputJarak;
    private Spinner spinnerJarakDari, spinnerJarakKe;
    private Button btnKonversiJarak;
    private TextView tvHasilJarak;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jarak);

        inputJarak = findViewById(R.id.inputJarak);
        spinnerJarakDari = findViewById(R.id.spinnerJarakDari);
        spinnerJarakKe = findViewById(R.id.spinnerJarakKe);
        btnKonversiJarak = findViewById(R.id.btnKonversiJarak);
        tvHasilJarak = findViewById(R.id.tvHasilJarak);

        String[] satuanJarak = {"mm", "cm", "m", "km"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, satuanJarak);
        spinnerJarakDari.setAdapter(adapter);
        spinnerJarakKe.setAdapter(adapter);

        btnKonversiJarak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double nilai = Double.parseDouble(inputJarak.getText().toString());
                String dari = spinnerJarakDari.getSelectedItem().toString();
                String ke = spinnerJarakKe.getSelectedItem().toString();
                double hasil = konversiJarak(nilai, dari, ke);
                tvHasilJarak.setText("Hasil: " + hasil + " " + ke);
            }
        });
    }

    private double konversiJarak(double nilai, String dari, String ke) {
        // konversi ke meter dulu
        switch (dari) {
            case "mm": nilai = nilai / 1000; break;
            case "cm": nilai = nilai / 100; break;
            case "km": nilai = nilai * 1000; break;
        }
        // konversi dari meter ke satuan tujuan
        switch (ke) {
            case "mm": return nilai * 1000;
            case "cm": return nilai * 100;
            case "km": return nilai / 1000;
            default: return nilai;
        }
    }
}

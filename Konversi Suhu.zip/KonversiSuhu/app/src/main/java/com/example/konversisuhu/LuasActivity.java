package com.example.konversisuhu;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class LuasActivity extends AppCompatActivity {

    private EditText inputLuas;
    private Spinner spinnerLuasDari, spinnerLuasKe;
    private Button btnKonversiLuas;
    private TextView tvHasilLuas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_luas);

        inputLuas = findViewById(R.id.inputLuas);
        spinnerLuasDari = findViewById(R.id.spinnerLuasDari);
        spinnerLuasKe = findViewById(R.id.spinnerLuasKe);
        btnKonversiLuas = findViewById(R.id.btnKonversiLuas);
        tvHasilLuas = findViewById(R.id.tvHasilLuas);

        String[] satuanLuas = {"m²", "cm²", "km²", "ha"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, satuanLuas);
        spinnerLuasDari.setAdapter(adapter);
        spinnerLuasKe.setAdapter(adapter);

        btnKonversiLuas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double nilai = Double.parseDouble(inputLuas.getText().toString());
                String dari = spinnerLuasDari.getSelectedItem().toString();
                String ke = spinnerLuasKe.getSelectedItem().toString();
                double hasil = konversiLuas(nilai, dari, ke);
                tvHasilLuas.setText("Hasil: " + hasil + " " + ke);
            }
        });
    }

    private double konversiLuas(double nilai, String dari, String ke) {
        // konversi ke m² dulu
        switch (dari) {
            case "cm²": nilai = nilai / 10000; break;
            case "km²": nilai = nilai * 1_000_000; break;
            case "ha": nilai = nilai * 10_000; break;
        }
        // konversi dari m² ke satuan tujuan
        switch (ke) {
            case "cm²": return nilai * 10000;
            case "km²": return nilai / 1_000_000;
            case "ha": return nilai / 10_000;
            default: return nilai;
        }
    }
}
